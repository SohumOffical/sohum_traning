const mongoose = require('mongoose');

const BookSchema = mongoose.Schema({
    book_name: String,
    isbn: Number,
    author: String,
    price: Number
}, {
    timestamps: true
});

module.exports = mongoose.model('Book', BookSchema);