const mongoose = require('mongoose');

const OrderSchema = mongoose.Schema({
    food_name: String,
    customer: String,
    food_qty: Number,
    price: Number
}, {
    timestamps: true
});

module.exports = mongoose.model('Order', OrderSchema);