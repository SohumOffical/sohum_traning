const Order = require('../models/model.js');

exports.create = (req, res) => {
    // Validate request
    if (!req.body.food_name) {
        return res.status(400).send({
            message: "food_name content can not be empty"
        });
    }
    if (!req.body.customer) {
        return res.status(400).send({
            message: "customer content can not be empty"
        });
    }
    if (!req.body.food_qty) {
        return res.status(400).send({
            message: "food_qty content can not be empty"
        });
    }
    if (!req.body.price) {
        return res.status(400).send({
            message: "price content can not be empty"
        });
    }

    // Create a Order
    const order = new Order({
        food_name: req.body.food_name,
        customer: req.body.customer,
        food_qty: req.body.food_qty,
        price: req.body.price
    });

    // Save Order in the database
    order.save()
        .then(data => {
            res.send(data);
        }).catch(err => {
            res.status(500).send({
                message: err.message || "Some error occurred while Placing the Order."
            });
        });
};

// Retrieve and return all Orders from the database.
exports.findAll = (req, res) => {
    Order.find()
        .then(orders => {
            res.send(orders);
        }).catch(err => {
            res.status(500).send({
                message: err.message || "Some error occurred while retrieving Orders."
            });
        });
};


exports.findOne = (req, res) => {
    Order.findById(req.params.orderId)
        .then(order => {
            if (!order) {
                return res.status(404).send({
                    message: "Order not found with id " + req.params.orderId
                });
            }
            res.send(order);
        }).catch(err => {
            if (err.kind === 'ObjectId') {
                return res.status(404).send({
                    message: "Note not found with id " + req.params.noteId
                });
            }
            return res.status(500).send({
                message: "Error retrieving order with id " + req.params.noteId
            });
        });
};

exports.update = (req, res) => {
    // Validate Request
    if (!req.body.food_name) {
        return res.status(400).send({
            message: "food name can not be empty"
        });
    }

    // Find order and update it with the request body
    Order.findByIdAndUpdate(req.params.orderId, {
        food_name: String,
        customer: String,
        food_qty: Number,
        price: Number
    }, { new: true })
        .then(order => {
            if (!order) {
                return res.status(404).send({
                    message: "Note not found with id " + req.params.noteId
                });
            }
            if (!req.body.customer) {
                return res.status(400).send({
                    message: "customer content can not be empty"
                });
            }
            if (!req.body.food_qty) {
                return res.status(400).send({
                    message: "food_qty content can not be empty"
                });
            }
            if (!req.body.price) {
                return res.status(400).send({
                    message: "price content can not be empty"
                });
            }

            res.send(order);
        }).catch(err => {
            if (err.kind === 'ObjectId') {
                return res.status(404).send({
                    message: "Orders not found with id " + req.params.orderId
                });
            }
            return res.status(500).send({
                message: "Error updating order with id " + req.params.orderId
            });
        });
};

// Delete a Order with the specified orderId in the request
exports.delete = (req, res) => {
    Order.findByIdAndRemove(req.params.orderId)
        .then(order => {
            if (!order) {
                return res.status(404).send({
                    message: "Order not found with id " + req.params.orderId
                });
            }
            res.send({ message: "NOrder deleted successfully!" });
        }).catch(err => {
            if (err.kind === 'ObjectId' || err.name === 'NotFound') {
                return res.status(404).send({
                    message: "order not found with id " + req.params.orderId
                });
            }
            return res.status(500).send({
                message: "Could not delete order with id " + req.params.orderId
            });
        });
};