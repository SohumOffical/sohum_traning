module.exports = (app) => {
    const Orders = require('../controller/controller.js');

    // Place a new Order
    app.post('/orders', Orders.create);

    // Retrieve all Orders
    app.get('/orders', Orders.findAll);

    // Retrieve a single Order with OrderId
    app.get('/orders/:orderId', Orders.findOne);

    // Update a Order with OrderId
    app.put('/orders/:orderId', Orders.update);

    // Delete a Order with OrderId
    app.delete('/orders/:orderId', Orders.delete);
}